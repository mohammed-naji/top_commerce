<?php $__env->startSection('title', 'All Roles | ' . env('APP_NAME')); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .table th, .table td {
        vertical-align: middle;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0 text-gray-800">All Roles</h1>
    <a class="btn btn-dark" href="<?php echo e(route('admin.roles.create')); ?>">Add New Role</a>
</div>

<?php if(session('msg')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?>"><?php echo e(session('msg')); ?></div>
<?php endif; ?>

<table class="table table-hover table-bordered table-striped">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Actions</th>
    </tr>
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($role->id); ?></td>
        <td><?php echo e($role->name); ?></td>

        <td>
            <a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.roles.edit', $role->id)); ?>"><i class="fas fa-edit"></i></a>
            <form class="d-inline" action="<?php echo e(route('admin.roles.destroy', $role->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-sm btn-danger" onclick="return confirm('are you sure?')"><i class="fas fa-trash"></i></button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<div id="custom-menu" style="position:absolute;width:200px;background:#f00;color:#fff;display:none">
    Bahaa
</div>
<?php echo e($roles->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

// window.oncontextmenu = function (e) {
//     console.log(e);
//     // alert('ما في عنا فحص العناصر روح اسرق من حد غيرنا')

//     document.querySelector('#custom-menu').style.display = 'block';
//     document.querySelector('#custom-menu').style.top = e.offsetY+'px';
//     document.querySelector('#custom-menu').style.left = e.offsetX+'px';

//     return false;
// }

// window.onclick = function (e) {
//     document.querySelector('#custom-menu').style.display = 'none';
// }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>