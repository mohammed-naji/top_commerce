<div class="mb-3">
    <label>Name</label>
    <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($product->name); ?>" />
</div>

<div class="mb-3">
    <label>Image</label>
    <input type="file" name="image" class="form-control" />
    <?php if($product->image): ?>
    <img width="100" src="<?php echo e(asset('uploads/images/products/'.$product->image)); ?>" alt="">
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Description</label>
    <textarea class="tinytext" class="form-control" placeholder="Description" name="description" rows="5"><?php echo e($product->description); ?></textarea>
</div>

<div class="mb-3">
    <label>Price</label>
    <input type="number" name="price" class="form-control" placeholder="Price"  value="<?php echo e($product->price); ?>" />
</div>

<div class="mb-3">
    <label>Sale Price</label>
    <input type="number" name="sale_price" class="form-control" placeholder="Sale Price" value="<?php echo e($product->sale_price); ?>" />
</div>

<div class="mb-3">
    <label>Quantity</label>
    <input type="number" name="quantity" class="form-control" placeholder="Quantity" value="<?php echo e($product->quantity); ?>" />
</div>


<div class="mb-3">
    <label>Category</label>

    <select name="category_id" class="form-control">
        <option value="" disabled selected>--Select--</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e($product->category_id == $item->id ? 'selected' : ''); ?>  value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH C:\wamp64\www\top_commerce\resources\views/admin/products/form.blade.php ENDPATH**/ ?>