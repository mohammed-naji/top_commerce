<?php $__env->startSection('title', 'All Products | ' . env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0 text-gray-800">Create New Product</h1>
    <a class="btn btn-dark" href="<?php echo e(route('admin.products.index')); ?>">All Products</a>
</div>

<?php echo $__env->make('admin.parts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('admin.products.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<button class="btn btn-success px-5">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/admin/products/create.blade.php ENDPATH**/ ?>