<?php $__env->startSection('title', 'All Products | ' . env('APP_NAME')); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .table th, .table td {
        vertical-align: middle;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0 text-gray-800">All Products</h1>
    <a class="btn btn-dark" href="<?php echo e(route('admin.products.create')); ?>">Add New Product</a>
</div>

<?php if(session('msg')): ?>
    <div class="alert alert-<?php echo e(session('type')); ?>"><?php echo e(session('msg')); ?></div>
<?php endif; ?>

<table class="table table-hover table-bordered table-striped">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Image</th>
        <th>Price</th>
        <th>Sale Price</th>
        <th>Quantity</th>
        <th>Category</th>
        <th>Created At</th>
        <th>Actions</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($product->id); ?></td>
        <td><?php echo e($product->name); ?></td>
        <td><img width="100" src="<?php echo e(asset('uploads/images/products/'.$product->image)); ?>" alt=""></td>
        <td><?php echo e($product->price); ?></td>
        <td><?php echo e($product->sale_price); ?></td>
        <td>
            <?php if($product->quantity > 20): ?>
                <span class="badge badge-success"><?php echo e($product->quantity); ?></span>
            <?php else: ?>
                <span class="badge badge-danger"><?php echo e($product->quantity); ?></span>
            <?php endif; ?>
        </td>
        <td><?php echo e($product->category->name); ?></td>
        <td><?php echo e($product->created_at->diffForHumans()); ?></td>
        <td>
            <a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.products.edit', $product->id)); ?>"><i class="fas fa-edit"></i></a>
            <form class="d-inline" action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-sm btn-danger" onclick="return confirm('are you sure?')"><i class="fas fa-trash"></i></button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="9" class="text-center text-danger">No Data Yet</td>
    </tr>
    <?php endif; ?>
</table>

<div id="custom-menu" style="position:absolute;width:200px;background:#f00;color:#fff;display:none">
    Bahaa
</div>
<?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

// window.oncontextmenu = function (e) {
//     console.log(e);
//     // alert('ما في عنا فحص العناصر روح اسرق من حد غيرنا')

//     document.querySelector('#custom-menu').style.display = 'block';
//     document.querySelector('#custom-menu').style.top = e.offsetY+'px';
//     document.querySelector('#custom-menu').style.left = e.offsetX+'px';

//     return false;
// }

// window.onclick = function (e) {
//     document.querySelector('#custom-menu').style.display = 'none';
// }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>