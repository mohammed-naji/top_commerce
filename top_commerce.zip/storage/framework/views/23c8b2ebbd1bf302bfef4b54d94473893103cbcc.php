<?php $__env->startSection('title', 'Edit Category | ' . env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0 text-gray-800">Edit Category</h1>
    <a class="btn btn-dark" href="<?php echo e(route('admin.categories.index')); ?>">All Categories</a>
</div>

<form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
<div class="mb-3">
    <label>Name</label>
    <input type="text" name="name" class="form-control" value="<?php echo e($category->name); ?>" placeholder="Name" />
</div>

<div class="mb-3">
    <label>Image</label>
    <input id="img-input" type="file" name="image" class="form-control" />
    <img id="img-item" width="70" src="<?php echo e(asset('uploads/images/'.$category->image)); ?>" alt="">
</div>

<div class="mb-3">
    <label>Parent</label>
    <select name="parent_id" class="form-control">
        <option value="" disabled selected>--Select--</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e($category->parent_id == $item->id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<button class="btn btn-info px-5">Edit</button>
</form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
document.querySelector('#img-item').onclick = function() {
    document.querySelector('#img-input').click();
}

document.getElementById('img-input').onchange = function (evt) {
    var tgt = evt.target || window.event.srcElement,
        files = tgt.files;

    // FileReader support
    if (FileReader && files && files.length) {
        var fr = new FileReader();
        fr.onload = function () {
            document.getElementById('img-item').src = fr.result;
        }
        fr.readAsDataURL(files[0]);
    }

    // Not supported
    else {
        // fallback -- perhaps submit the input to an iframe and temporarily store
        // them on the server until the user's session ends.
    }
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>