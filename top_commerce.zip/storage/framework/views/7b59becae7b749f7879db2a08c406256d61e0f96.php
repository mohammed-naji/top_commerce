<?php $__env->startSection('title', 'All Categories | ' . env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0 text-gray-800">Create New Category</h1>
    <a class="btn btn-dark" href="<?php echo e(route('admin.categories.index')); ?>">All Categories</a>
</div>

<?php echo $__env->make('admin.parts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('admin.categories.store')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<div class="mb-3">
    <label>Name</label>
    <input type="text" name="name" class="form-control" placeholder="Name" />
</div>

<div class="mb-3">
    <label>Image</label>
    <input type="file" name="image" class="form-control" />
</div>

<div class="mb-3">
    <label>Parent</label>
    <select name="parent_id" class="form-control">
        <option value="" disabled selected>--Select--</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<button class="btn btn-success px-5">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>