<?php $__env->startSection('content'); ?>
<!-- Start Bradcaump area -->
<div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(<?php echo e(asset('siteasset/images/bg/2.jpg')); ?>) no-repeat scroll center center / cover ;">
    <div class="ht__bradcaump__wrap">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="bradcaump__inner text-center">
                        <h2 class="bradcaump-title">Thanks</h2>
                        <nav class="bradcaump-inner">
                            <a class="breadcrumb-item" href="<?php echo e(route('site.index')); ?>">Home</a>
                            <span class="brd-separetor">/</span>
                            <span class="breadcrumb-item active">Thanks</span>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Bradcaump area -->
<!-- Start Checkout Area -->
<section class="our-checkout-area ptb--120 bg__white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">`
                <div class="alert alert-success">
                    Payment Done
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Checkout Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.masetr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/site/checkout_success.blade.php ENDPATH**/ ?>