<?php $__env->startSection('content'); ?>

        <!-- End Offset Wrapper -->
        <!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(<?php echo e(asset('siteasset/images/bg/2.jpg')); ?>) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner text-center">
                                <h2 class="bradcaump-title">Cart</h2>
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="index.html">Home</a>
                                  <span class="brd-separetor">/</span>
                                  <span class="breadcrumb-item active">Cart</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="cart-main-area ptb--120 bg__white">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <form action="<?php echo e(route('update_cart')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="table-content table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product-thumbnail">Image</th>
                                            <th class="product-name">Product</th>
                                            <th class="product-price">Price</th>
                                            <th class="product-quantity">Quantity</th>
                                            <th class="product-subtotal">Total</th>
                                            <th class="product-remove">Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $total = 0;
                                        ?>
                                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total += $cart->price * $cart->qty;
                                        ?>
                                        <tr>
                                            <td class="product-thumbnail"><a href="<?php echo e(route('site.product', $cart->product_id)); ?>"><img src="<?php echo e(asset('uploads/images/products/'.$cart->product->image)); ?>" alt="product img" /></a></td>
                                            <td class="product-name"><a href="<?php echo e(route('site.product', $cart->product_id)); ?>"><?php echo e($cart->product->name); ?></a></td>
                                            <td class="product-price"><span class="amount"><?php echo e($cart->price); ?></span></td>
                                            <td class="product-quantity"><input type="number" name="new_qty[<?php echo e($cart->id); ?>]" value="<?php echo e($cart->qty); ?>" /></td>
                                            <td class="product-subtotal">$<?php echo e($cart->price * $cart->qty); ?></td>
                                            <td class="product-remove"><a href="<?php echo e(route('remove_cart', $cart->id)); ?>">X</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                            <div class="row">
                                <div class="col-md-8 col-sm-7 col-xs-12">
                                    <div class="buttons-cart">
                                        <input type="submit" value="Update Cart" />
                                        <a href="<?php echo e(route('site.shop')); ?>">Continue Shopping</a>
                                    </div>
                                    
                                </div>
                                <div class="col-md-4 col-sm-5 col-xs-12">
                                    <div class="cart_totals">
                                        <h2>Cart Totals</h2>
                                        <table>
                                            <tbody>
                                                <tr class="cart-subtotal">
                                                    <th>Subtotal</th>
                                                    <td><span class="amount">$<?php echo e($total); ?></span></td>
                                                </tr>
                                                
                                                <tr class="order-total">
                                                    <th>Total</th>
                                                    <td>
                                                        <strong><span class="amount">$<?php echo e(number_format($total, 2)); ?></span></strong>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="wc-proceed-to-checkout">
                                            <a href="<?php echo e(route('checkout')); ?>">Proceed to Checkout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- cart-main-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.masetr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\top_commerce\resources\views/site/cart.blade.php ENDPATH**/ ?>