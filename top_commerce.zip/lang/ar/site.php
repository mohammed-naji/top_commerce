<?php

return [
    'Home' => 'الرئيسية جديد'
];
