<?php

return [
    'Home' => 'Home'
];
